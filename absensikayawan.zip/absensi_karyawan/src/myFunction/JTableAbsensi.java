/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myFunction;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import myEntity.absensi;
/**
 *
 * @author LENOVO
 */
public class JTableAbsensi  extends AbstractTableModel {
    List<absensi> list = new ArrayList<>();
    public void add(absensi ab)
    {
        list.add(ab);
        fireTableRowsInserted(getRowCount(),getColumnCount());
    }
    
    @Override
    public int getRowCount()
    {
        return list.size();
    }
    
    @Override
    public int getColumnCount()
    {
        return 8;
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        switch (columnIndex)
        {
            case 0 : return list.get(rowIndex).getKode_absensi();
            case 1 : return list.get(rowIndex).getNama();
            case 2 : return list.get(rowIndex).getAlamat();
            case 3 : return list.get(rowIndex).getTelp();
            case 4 : return list.get(rowIndex).getEmail();
            case 5 : return list.get(rowIndex).getKeterangan();
            case 6 : return list.get(rowIndex).getAlasan();
            case 7 : return list.get(rowIndex).getTanggal();    
            
            default : return null;
        }
    }
    
    @Override
    public String getColumnName (int column)
    {
        switch (column)
        {
            case 0 : return "KODE";
            case 1 : return "NAMA";
            case 2 : return "ALAMAT";
            case 3 : return "TELP";
            case 4 : return "EMAIL";
            case 5 : return "KETERANGAN";
            case 6 : return "ALASAN";
            case 7 : return "TANGGAL";
            default : return null;
        }
    }
    
    public void removeRow(int i, int l)
    {
        list.remove(i);
        fireTableRowsDeleted(i,l);
    }   

    public void add(absensi s) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
