/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myEntity;

/**
 *
 * @author LENOVO
 */
public class absensi {
    private String nama, alamat, telp, email, keterangan, alasan, tanggal;

    /**
     * @return the nama
     */
    public String getNama() {
        return nama;
    }

    /**
     * @param nama the nama to set
     */
    public void setNama(String nama) {
        this.nama = nama;
    }

    /**
     * @return the alamat
     */
    public String getAlamat() {
        return alamat;
    }

    /**
     * @param alamat the alamat to set
     */
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    /**
     * @return the telp
     */
    public String getTelp() {
        return telp;
    }

    /**
     * @param telp the telp to set
     */
    public void setTelp(String telp) {
        this.telp = telp;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the keterangan
     */
    public String getKeterangan() {
        return keterangan;
    }

    /**
     * @param keterangan the keterangan to set
     */
    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    /**
     * @return the alasan
     */
    public String getAlasan() {
        return alasan;
    }

    /**
     * @param alasan the alasan to set
     */
    public void setAlasan(String alasan) {
        this.alasan = alasan;
    }

    /**
     * @return the tanggal
     */
    public String getTanggal() {
        return tanggal;
    }

    /**
     * @param tanggal the tanggal to set
     */
    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
        
        public absensi (String nama, String alamat, String telp, String email,String keterangan,String alasan,String tanggal){
        this.nama = nama;
        this.alamat = alamat;
        this.telp = telp;
        this.email = email;
        this.keterangan = keterangan;
        this.alasan = alasan;
        this.tanggal = tanggal;
        
    }
    
    private int kode_absensi;
    
    //getter & setter
    public int getKode_absensi(){
        return kode_absensi;
    }
    
    public void setKode_absensi(int kode_absensi){
        this.kode_absensi = kode_absensi;
    }
    
    //overloading constructor
    public absensi(){}
    
    }

