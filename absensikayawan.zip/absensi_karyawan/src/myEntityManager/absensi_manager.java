/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myEntityManager;
import myEntity.absensi;
import myFunction.fungsi;
/**
 *
 * @author LENOVO
 */
public class absensi_manager {
    int i;
    
    public int inputData(absensi ab)
    {
        i=0;
        try
        {
            String sql =  "insert into absensi(nama_karyawan,alamat,telp,email, keterangan, alasan, tanggal_absensi)"+
                    "values('"+ab.getNama()+"','"+ab.getAlamat()+"','"+
                    ab.getTelp()+"','"+ab.getEmail()+"','"+ab.getKeterangan()+"','"+ab.getAlasan()+"','"+ab.getTanggal()+"')";
            
            i=fungsi.EQuery(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
    }
    
    public int hapusData(int ID)
    {
        i=0;
        try
        {
            String sql =  "delete from absensi where kode_absensi="+ID+"";
            i=fungsi.EQuery(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
    }
}