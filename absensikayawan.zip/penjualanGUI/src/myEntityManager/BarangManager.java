/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myEntityManager;
import myEntity.Barang;
import myFunction.Fungsi;
/**
 *
 * @author MIZAR
 */
public class BarangManager {
     int i;
    
    public int inputData(Barang supp)
    {
        i=0;
        try
        {
            String sql =  "insert into barang(nama_barang,harga_jual,stok,kode_supplier)"+
                    "values('"+supp.getNama()+"','"+supp.getHarga()+"','"+
                    supp.getStok()+"','"+supp.getKode_sup()+"')";
            
            i=Fungsi.EQuery(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
    }
    
}
