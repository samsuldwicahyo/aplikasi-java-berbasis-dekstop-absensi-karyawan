/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myEntityManager;
import myEntity.Supplier;
import myFunction.Fungsi;
/**
 *
 * @author MIZAR
 */
public class SupplierManager {
    int i;
    
    public int inputData(Supplier supp)
    {
        i=0;
        try
        {
            String sql =  "insert into supplier(nama_supplier,alamat,telp,email)"+
                    "values('"+supp.getNama()+"','"+supp.getAlamat()+"','"+
                    supp.getTelp()+"','"+supp.getEmail()+"')";
            
            i=Fungsi.EQuery(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
    }
    
    public int hapusData(int ID)
    {
        i=0;
        try
        {
            String sql =  "delete from supplier where kode_supplier="+ID+"";
            i=Fungsi.EQuery(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
    }
}
