/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myFunction;
import java.sql.*;
import myConnection.Koneksi;
/**
 *
 * @author MIZAR
 */
public class Fungsi {
    static Connection Cnn;
    static Koneksi db = new Koneksi();
    static Statement st;
    static int i;
    
    //Exekusi perintah insert, Update, Delete
    public static int EQuery (String sql) throws SQLException
    {
        i = 0;
        try {
            Cnn = db.getConnection();
            st = Cnn.createStatement();
            i= st.executeUpdate(sql);
            return i;
        }
        catch (Exception e)
        {
            return i;
        }
        finally
        {
            Cnn.close();
        }
    }
}
