/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualangui;

/**
 *
 * @author MIZAR
 */
public class frmUtama extends javax.swing.JFrame {
    public frmUtama() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnMaster = new javax.swing.JMenu();
        mnSupplier = new javax.swing.JMenuItem();
        mnBarang = new javax.swing.JMenuItem();
        mnKeluar = new javax.swing.JMenuItem();
        mnPembelian = new javax.swing.JMenu();
        jMenuItem10 = new javax.swing.JMenuItem();
        mnPenjualan = new javax.swing.JMenuItem();
        mnLaporan = new javax.swing.JMenu();
        mnRekapPembelian = new javax.swing.JMenuItem();
        mnRekapPenjualan = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mnMaster.setText("Master ");

        mnSupplier.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        mnSupplier.setText("Supplier");
        mnSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnSupplierActionPerformed(evt);
            }
        });
        mnMaster.add(mnSupplier);

        mnBarang.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mnBarang.setText("Barang");
        mnBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnBarangActionPerformed(evt);
            }
        });
        mnMaster.add(mnBarang);

        mnKeluar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_K, java.awt.event.InputEvent.CTRL_MASK));
        mnKeluar.setText("Keluar");
        mnKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnKeluarActionPerformed(evt);
            }
        });
        mnMaster.add(mnKeluar);

        jMenuBar1.add(mnMaster);

        mnPembelian.setText("Transaksi");

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem10.setText("Pembelian");
        mnPembelian.add(jMenuItem10);

        mnPenjualan.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_J, java.awt.event.InputEvent.CTRL_MASK));
        mnPenjualan.setText("Penjualan");
        mnPembelian.add(mnPenjualan);

        jMenuBar1.add(mnPembelian);

        mnLaporan.setText("Laporan");

        mnRekapPembelian.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.SHIFT_MASK));
        mnRekapPembelian.setText("Rekap Pembelian");
        mnRekapPembelian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnRekapPembelianActionPerformed(evt);
            }
        });
        mnLaporan.add(mnRekapPembelian);

        mnRekapPenjualan.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_J, java.awt.event.InputEvent.SHIFT_MASK));
        mnRekapPenjualan.setText("Rekap Penjualan");
        mnRekapPenjualan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnRekapPenjualanActionPerformed(evt);
            }
        });
        mnLaporan.add(mnRekapPenjualan);

        jMenuBar1.add(mnLaporan);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 712, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnSupplierActionPerformed
        frmSupplier sp = new frmSupplier();
        sp.setVisible(true);
    }//GEN-LAST:event_mnSupplierActionPerformed

    private void mnRekapPembelianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnRekapPembelianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mnRekapPembelianActionPerformed

    private void mnRekapPenjualanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnRekapPenjualanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mnRekapPenjualanActionPerformed

    private void mnBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnBarangActionPerformed
        // TODO add your handling code here:
        frmBarang br = new frmBarang();
        br.setVisible(true);
    }//GEN-LAST:event_mnBarangActionPerformed

    private void mnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnKeluarActionPerformed
        dispose();
    }//GEN-LAST:event_mnKeluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
          
            @Override
            public void run() {
                new frmUtama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem mnBarang;
    private javax.swing.JMenuItem mnKeluar;
    private javax.swing.JMenu mnLaporan;
    private javax.swing.JMenu mnMaster;
    private javax.swing.JMenu mnPembelian;
    private javax.swing.JMenuItem mnPenjualan;
    private javax.swing.JMenuItem mnRekapPembelian;
    private javax.swing.JMenuItem mnRekapPenjualan;
    private javax.swing.JMenuItem mnSupplier;
    // End of variables declaration//GEN-END:variables
}
