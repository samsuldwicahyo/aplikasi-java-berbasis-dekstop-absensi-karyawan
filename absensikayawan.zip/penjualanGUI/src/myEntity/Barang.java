/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myEntity;

/**
 *
 * @author MIZAR
 */
public class Barang {
    private String nama,kode_sup;
    private int harga,stok;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getKode_sup() {
        return kode_sup;
    }

    public void setKode_sup(String kode_sup) {
        this.kode_sup = kode_sup;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public int getStok() {
        return stok;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }
    
      public Barang (String nama, String kode_sup, int harga, int stok){
        this.nama = nama;
        this.kode_sup = kode_sup;
        this.harga = harga;
        this.stok = stok;
    }
    
}
